# Shelf firmware for the Odroid GO

Shelf is the launcher. It plays NES, Game Boy and Game Boy Color games using the
two emulators from your Retro ESP32 firmware, which `tools/mkfw.py` copies into
`Shelf.fw`. Your ROMs and existing saves keep working, because Shelf uses the same
folders Retro ESP32 does.

## What you need

- ESP-IDF **v4.4** (any 4.4.x). Newer major versions changed several driver APIs this
  code uses. Installation guide: https://docs.espressif.com/projects/esp-idf/en/v4.4.7/esp32/get-started/
  (on Windows, the "ESP-IDF Tools Installer" is easiest; pick v4.4.x).
- Python 3 with Pillow for the art converter: `pip install pillow`
- Your `Retro ESP32.fw`.

## 1. Build

Open the ESP-IDF command prompt (or run `export.sh` / `export.bat`), then:

    cd shelf-firmware
    idf.py set-target esp32
    idf.py build

This produces `build/shelf.bin`. If you change `sdkconfig.defaults`, delete the `sdkconfig`
file and the `build` folder first, because settings are only read from it on a fresh build.

Use `idf.py build` only. Don't run `idf.py flash`:
it would replace the Odroid GO's firmware menu, which is how Shelf gets installed.

## 2. Package

    python tools/mkfw.py --launcher build/shelf.bin --donor "path/to/Retro ESP32.fw" --out Shelf.fw

## 3. Set up the SD card

    /odroid/firmware/Shelf.fw
    /roms/nes/      .nes or .zip files
    /roms/gb/       .gb or .zip files
    /roms/gbc/      .gbc or .zip files
    /shelf/art/     written by the art converter (step 4)

Saves live in `/odroid/data/`, the same place Retro ESP32 keeps them.

## 4. Add your art (optional, any time)

Make a folder with `nes`, `gb` and `gbc` subfolders. Name each image after its ROM file
(without the extension), followed by `.box` or `.label`:

    my-art/nes/Super Game (USA).box.png
    my-art/nes/Super Game (USA).label.png

Then convert straight onto the SD card (or into a folder you copy over later):

    python tools/convert_art.py my-art E:\

Images keep their own proportions and are shrunk to fit: NES labels up to 106×88, Game Boy
labels up to 90×78, NES boxes up to 112×160, Game Boy boxes up to 128×128. Add `--preview`
to also get PNGs of exactly what will show on screen. Games without art get a generated
label and box.

## 5. Install

Turn the Odroid GO off. Hold **B** and turn it on to open the firmware menu, pick
`Shelf.fw`, and confirm. To go back to Retro ESP32 at any time, flash `Retro ESP32.fw` the
same way.

## Saving your game

Press **Menu** while playing and choose **Save & Quit**. The emulator saves your spot and
returns to Shelf, which plays the eject animation. From then on, the game's page offers
**Resume** and **Start over**. Choosing plain **Quit** leaves without saving.

## If something goes wrong

**Build errors:** copy the full error text and send it to me.

**The screen looks wrong.** Change `LCD_MADCTL` near the top of `main/hal.c` (it's `0xA0`), then rebuild:
- mirrored left to right: try `0x20`, then `0xE0`
- red and blue swapped: add `0x08` to whatever value you're using, for example `0xA8`

**It won't start after an update.** Shelf runs its flash and PSRAM at 80 MHz for speed. If a
unit doesn't like that, delete the last two lines of `sdkconfig.defaults`, delete the file
`sdkconfig` and the `build` folder, then build again.

**A game won't start.** Shelf shows what went wrong on screen. Send me a photo of it.

**Anything else:** connect the Odroid GO over USB and run `idf.py -p PORT monitor`, where
`PORT` is `COM3` or similar on Windows, or `/dev/ttyUSB0` on Linux. Send me what it prints.

## How it differs from the prototype

- **No clock.** The Odroid GO has no clock chip, so the time and "played 3 days ago"
  are gone. "Recently played" sorting still works, from the order you played games in.
- **Saving is a menu choice.** Saving happens through the emulator's Save & Quit. Making
  Menu save automatically would mean rebuilding the emulators from source, a good next step.
- **No "left off" thumbnail.** The detail page shows that a save exists instead of a
  thumbnail, since these emulators don't store screenshots with their saves.

## Files

    main/hal.c        screen, buttons, battery, SD card
    main/gfx.c        drawing and the bitmap font (font.c)
    main/art.c        cartridges, labels, boxes, art loading
    main/backdrop.c   the space backdrops
    main/ui.c         every screen and animation
    main/library.c    ROM scanning, play time, favorites, sorting
    main/system.c     settings and the handoff to the emulators
    main/audio.c      sound effects
    tools/mkfw.py     builds Shelf.fw
    tools/convert_art.py
