#!/usr/bin/env python3
"""Package Shelf into a .fw file the Odroid GO firmware menu can install.

The NES and Game Boy emulators are copied out of the Retro ESP32 .fw you
already have, so nothing else needs to be built:

    python mkfw.py --launcher ../build/shelf.bin --donor "Retro ESP32.fw" --out Shelf.fw

Partition order matters: the emulators return to slot 0 when you quit a game,
and Shelf starts them from slots 1 (NES) and 2 (Game Boy and Game Boy Color).
"""
import argparse
import struct
import sys
import zlib

MAGIC = b"ODROIDGO_FIRMWARE_V00_01"
TILE_W, TILE_H = 86, 48
ENTRY = struct.Struct("<BBBB16sII")      # type, subtype, 2 reserved, label, flags, partition size


def read_fw(path):
    d = open(path, "rb").read()
    if not d.startswith(MAGIC):
        sys.exit(f"{path} is not an Odroid GO .fw file")
    if zlib.crc32(d[:-4]) & 0xFFFFFFFF != struct.unpack("<I", d[-4:])[0]:
        sys.exit(f"{path} looks damaged (its checksum doesn't match)")
    off = len(MAGIC) + 40 + TILE_W * TILE_H * 2
    parts = {}
    while off < len(d) - 4:
        t, st, r1, r2, label, flags, size = ENTRY.unpack_from(d, off)
        off += ENTRY.size
        (n,) = struct.unpack_from("<I", d, off)
        off += 4
        parts[label.split(b"\0")[0].decode()] = (t, flags, size, d[off:off + n])
        off += n
    return parts


def rgb565(r, g, b):
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)


def make_tile():
    """The 86×48 picture shown in the firmware menu: a small cartridge on a starry sky."""
    px = [[rgb565(10, 11, 34)] * TILE_W for _ in range(TILE_H)]
    for i, (x, y) in enumerate([(5, 6), (17, 30), (70, 8), (78, 36), (60, 41), (9, 40), (30, 9), (52, 4)]):
        px[y][x] = rgb565(255, 255, 255) if i % 2 else rgb565(138, 148, 200)
    body, edge, label = rgb565(133, 135, 143), rgb565(40, 41, 46), rgb565(255, 122, 144)
    x0, y0, w, h = 30, 7, 26, 34
    for y in range(y0, y0 + h):
        for x in range(x0, x0 + w):
            px[y][x] = edge if x in (x0, x0 + w - 1) or y in (y0, y0 + h - 1) else body
    for y in range(y0 + 2, y0 + 7, 2):
        for x in range(x0 + 3, x0 + w - 3):
            px[y][x] = edge
    for y in range(y0 + 9, y0 + 27):
        for x in range(x0 + 3, x0 + w - 3):
            px[y][x] = label
    for y in range(y0 + 9, y0 + 13):
        for x in range(x0 + 3, x0 + w - 3):
            px[y][x] = rgb565(22, 20, 28)
    return b"".join(struct.pack("<H", v) for row in px for v in row)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--launcher", required=True, help="build/shelf.bin from idf.py build")
    ap.add_argument("--donor", required=True, help="the Retro ESP32 .fw to take the emulators from")
    ap.add_argument("--out", default="Shelf.fw")
    args = ap.parse_args()

    launcher = open(args.launcher, "rb").read()
    if launcher[:1] != b"\xE9":
        sys.exit(f"{args.launcher} doesn't look like an ESP32 app image")
    slot_size = 0x100000
    if len(launcher) > slot_size:
        sys.exit(f"Shelf is {len(launcher)} bytes, more than its {slot_size} byte slot")

    donor = read_fw(args.donor)
    for name in ("nesemu-go", "gnuboy-go"):
        if name not in donor:
            sys.exit(f"{args.donor} has no '{name}' partition (found: {', '.join(donor)})")

    parts = [
        ("shelf", 0x10, slot_size, launcher),
        ("nesemu-go", 0x11, donor["nesemu-go"][2], donor["nesemu-go"][3]),
        ("gnuboy-go", 0x12, donor["gnuboy-go"][2], donor["gnuboy-go"][3]),
    ]
    out = bytearray(MAGIC)
    out += b"Shelf".ljust(40, b"\0")
    out += make_tile()
    for label, subtype, size, data in parts:
        out += ENTRY.pack(0, subtype, 0, 0, label.encode().ljust(16, b"\0"), 0, size)
        out += struct.pack("<I", len(data)) + data
    out += struct.pack("<I", zlib.crc32(bytes(out)) & 0xFFFFFFFF)
    open(args.out, "wb").write(out)
    print(f"Wrote {args.out} ({len(out) // 1024} KB): Shelf, NES emulator, Game Boy emulator")


if __name__ == "__main__":
    main()
