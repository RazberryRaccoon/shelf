#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/stat.h>
#include <sys/time.h>
#include "nvs_flash.h"
#include "nvs.h"
#include "esp_ota_ops.h"
#include "esp_partition.h"
#include "esp_system.h"
#include "esp_log.h"
#include "esp_rom_crc.h"
#include "esp_spi_flash.h"
#include "mbedtls/md5.h"
#include "system.h"
#include "hal.h"

static const char *TAG = "system";
prefs_t PREFS;

// Partition slots inside Shelf.fw (see tools/mkfw.py): 0 = Shelf, 1 = NES, 2 = Game Boy / Color.
static const int EMU_SLOT[SYS_COUNT] = {1, 2, 2};

static uint8_t get_u8(nvs_handle_t h, const char *k, uint8_t def) { uint8_t v; return nvs_get_u8(h, k, &v) == ESP_OK ? v : def; }

void prefs_load(void)
{
    memset(&PREFS, 0, sizeof(PREFS));
    PREFS.sound = 1; PREFS.motion = 1; PREFS.gb_green = 1; PREFS.attract = 1; PREFS.volume = 3;
    nvs_handle_t h;
    if (nvs_open("Shelf", NVS_READONLY, &h) != ESP_OK) return;
    PREFS.sound = get_u8(h, "sound", 1);
    PREFS.motion = get_u8(h, "motion", 1);
    PREFS.gb_green = get_u8(h, "gbgreen", 1);
    PREFS.attract = get_u8(h, "attract", 1);
    PREFS.volume = get_u8(h, "volume", 3);
    PREFS.shelf = get_u8(h, "shelf", 0);
    char k[16];
    for (int s = 0; s < SYS_COUNT; s++) {
        snprintf(k, sizeof(k), "sort%d", s); PREFS.sort[s] = get_u8(h, k, 0);
        snprintf(k, sizeof(k), "sel%d", s);
        size_t len = sizeof(PREFS.sel[s]);
        if (nvs_get_str(h, k, PREFS.sel[s], &len) != ESP_OK) PREFS.sel[s][0] = 0;
    }
    nvs_close(h);
}

void prefs_save(void)
{
    nvs_handle_t h;
    if (nvs_open("Shelf", NVS_READWRITE, &h) != ESP_OK) return;
    nvs_set_u8(h, "sound", PREFS.sound);
    nvs_set_u8(h, "motion", PREFS.motion);
    nvs_set_u8(h, "gbgreen", PREFS.gb_green);
    nvs_set_u8(h, "attract", PREFS.attract);
    nvs_set_u8(h, "volume", PREFS.volume);
    nvs_set_u8(h, "shelf", PREFS.shelf);
    char k[16];
    for (int s = 0; s < SYS_COUNT; s++) {
        snprintf(k, sizeof(k), "sort%d", s); nvs_set_u8(h, k, PREFS.sort[s]);
        snprintf(k, sizeof(k), "sel%d", s); nvs_set_str(h, k, PREFS.sel[s]);
    }
    nvs_commit(h);
    nvs_close(h);
}

static int64_t now_s(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);   // the ESP32 keeps this running across a software restart
    return tv.tv_sec;
}

bool pending_take(char *key, int len, uint32_t *played)
{
    nvs_handle_t h;
    if (nvs_open("Shelf", NVS_READWRITE, &h) != ESP_OK) return false;
    size_t l = len;
    bool ok = nvs_get_str(h, "pend", key, &l) == ESP_OK && key[0];
    int64_t t0 = 0;
    nvs_get_i64(h, "pendt", &t0);
    if (ok) {
        int64_t d = now_s() - t0;
        *played = (d > 0 && d < 48 * 3600) ? (uint32_t)d : 0;   // unknown after a power cycle
        nvs_erase_key(h, "pend");
        nvs_commit(h);
    }
    nvs_close(h);
    return ok;
}

/* ---------- choosing which app starts next ----------
   ESP-IDF 4.4 can refuse the partition table the Odroid GO's firmware menu writes, so
   everything here can also work from the raw table in flash. */
#define TABLE_ADDR 0x8000
typedef struct __attribute__((packed)) {
    uint16_t magic;
    uint8_t type, subtype;
    uint32_t offset, size;
    char label[16];
    uint32_t flags;
} table_entry_t;
typedef struct { int n, checksum; table_entry_t e[32]; } raw_table_t;   // checksum: 0 none, 1 ok, 2 wrong
static const char *EMU_LABEL[SYS_COUNT] = {"nesemu-go", "gnuboy-go", "gnuboy-go"};

static void read_table(raw_table_t *t)
{
    static uint8_t buf[0xC00];
    memset(t, 0, sizeof(*t));
    if (spi_flash_read(TABLE_ADDR, buf, sizeof(buf)) != ESP_OK) return;
    for (int i = 0; i < 32; i++) {
        table_entry_t *e = (table_entry_t *)(buf + i * 32);
        if (e->magic == 0xEBEB) {   // checksum of everything before it
            uint8_t md5[16];
            mbedtls_md5_ret(buf, i * 32, md5);
            t->checksum = memcmp(md5, buf + i * 32 + 16, 16) ? 2 : 1;
            break;
        }
        if (e->magic != 0x50AA) break;
        t->e[t->n++] = *e;
    }
}

static int same_label(const char *a, const char *b) { return !strncmp(a, b, 16); }

static int count_ota_slots(const raw_table_t *t)
{
    int n = 0;
    for (int i = 0; i < t->n; i++) if (t->e[i].type == 0 && t->e[i].subtype >= 0x10 && t->e[i].subtype <= 0x1F) n++;
    return n;
}

// The record the bootloader reads to decide which app to start (two copies, newest wins).
typedef struct { uint32_t ota_seq; uint8_t seq_label[20]; uint32_t ota_state; uint32_t crc; } ota_entry_t;

static esp_err_t write_boot_record(uint32_t otadata, int slot_count, int slot)
{
    if (slot < 0 || slot_count <= 0) return ESP_ERR_INVALID_ARG;
    ota_entry_t e[2];
    uint32_t newest = 0;
    int newest_i = -1;
    for (int i = 0; i < 2; i++) {
        if (spi_flash_read(otadata + i * 0x1000, &e[i], sizeof(e[i])) != ESP_OK) memset(&e[i], 0xFF, sizeof(e[i]));
        bool valid = e[i].ota_seq != 0xFFFFFFFF && e[i].crc == esp_rom_crc32_le(UINT32_MAX, (const uint8_t *)&e[i].ota_seq, 4);
        if (valid && e[i].ota_seq > newest) { newest = e[i].ota_seq; newest_i = i; }
    }
    uint32_t seq = newest + 1;
    while ((seq - 1) % (uint32_t)slot_count != (uint32_t)slot) seq++;
    ota_entry_t n;
    memset(&n, 0xFF, sizeof(n));
    n.ota_seq = seq;
    n.crc = esp_rom_crc32_le(UINT32_MAX, (const uint8_t *)&n.ota_seq, 4);
    uint32_t addr = otadata + (newest_i == 0 ? 1 : 0) * 0x1000;
    esp_err_t err = spi_flash_erase_range(addr, 0x1000);
    if (err == ESP_OK) err = spi_flash_write(addr, &n, sizeof(n));
    return err;
}

// A plain-language summary of what's in flash, for the error screen and the serial log.
static void describe_flash(const raw_table_t *t, char *out, size_t len)
{
    int seen = 0;
    for (int type = 0; type < 2; type++) {
        esp_partition_iterator_t it = esp_partition_find((esp_partition_type_t)type, ESP_PARTITION_SUBTYPE_ANY, NULL);
        while (it) { seen++; it = esp_partition_next(it); }
    }
    char piece[128];
    snprintf(piece, sizeof(piece), "ESP-IDF sees %d partitions. Table in flash: %d entries, checksum %s.",
             seen, t->n, t->checksum == 1 ? "OK" : t->checksum == 2 ? "WRONG" : "none");
    str_copy(out, len, piece);
    for (int i = 0; i < t->n; i++) {
        snprintf(piece, sizeof(piece), " %.16s (%d/0x%02x)", t->e[i].label, t->e[i].type, t->e[i].subtype);
        size_t used = strlen(out);
        str_copy(out + used, len - used, piece);
    }
    snprintf(piece, sizeof(piece), " Settings storage: %s.", board_nvs_status() ? esp_err_to_name(board_nvs_status()) : "OK");
    size_t used = strlen(out);
    str_copy(out + used, len - used, piece);
}

void system_log_flash(void)
{
    static raw_table_t t;
    static char text[600];
    read_table(&t);
    describe_flash(&t, text, sizeof(text));
    ESP_LOGI(TAG, "%s", text);
}

static void clear_pending(void)
{
    nvs_handle_t h;
    if (nvs_open("Shelf", NVS_READWRITE, &h) == ESP_OK) { nvs_erase_key(h, "pend"); nvs_commit(h); nvs_close(h); }
}

const char *launch_game(game_t *g, bool resume)
{
    static char err_text[700];
    static raw_table_t table;
    char path[300], dir[64], key[160], about[600];
    lib_rom_path(g, path, sizeof(path));
    read_table(&table);

    // find the emulator: through ESP-IDF, or straight from the table in flash
    int slot = -1;
    uint32_t otadata = 0;
    const esp_partition_t *part = esp_partition_find_first(ESP_PARTITION_TYPE_APP, ESP_PARTITION_SUBTYPE_ANY, EMU_LABEL[g->sys]);
    if (!part) part = esp_partition_find_first(ESP_PARTITION_TYPE_APP, (esp_partition_subtype_t)(ESP_PARTITION_SUBTYPE_APP_OTA_MIN + EMU_SLOT[g->sys]), NULL);
    if (part) slot = part->subtype - ESP_PARTITION_SUBTYPE_APP_OTA_MIN;
    for (int i = 0; i < table.n && slot < 0; i++)
        if (table.e[i].type == 0 && same_label(table.e[i].label, EMU_LABEL[g->sys])) slot = table.e[i].subtype - 0x10;
    for (int i = 0; i < table.n; i++) if (table.e[i].type == 1 && table.e[i].subtype == 0x00) otadata = table.e[i].offset;

    if (slot < 0 || !otadata || board_nvs_status()) {
        describe_flash(&table, about, sizeof(about));
        snprintf(err_text, sizeof(err_text), "%s\n%s",
                 slot < 0 ? (g->sys == SYS_NES ? "The NES emulator wasn’t found." : "The Game Boy emulator wasn’t found.")
                 : !otadata ? "The boot record wasn’t found." : "Settings storage isn’t working, so the game can’t be handed over.",
                 about);
        ESP_LOGE(TAG, "%s", err_text);
        return err_text;
    }

    // make sure the emulator has somewhere to write its save
    char ext[16];
    const char *e = strrchr(g->file, '.');
    snprintf(ext, sizeof(ext), "%s", e ? e + 1 : "");
    for (char *p = ext; *p; p++) *p = tolower((unsigned char)*p);
    snprintf(dir, sizeof(dir), "/sd/odroid/data/%s", ext);
    board_bus_lock();
    mkdir("/sd/odroid", 0777);
    mkdir("/sd/odroid/data", 0777);
    mkdir(dir, 0777);
    board_bus_unlock();

    // the handoff the emulators read at startup
    nvs_handle_t h;
    if (nvs_open("Odroid", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_str(h, "RomFilePath", path);
        nvs_set_i32(h, "StartAction", resume ? 0 : 1);   // 0 = load the save if there is one, 1 = start over
        nvs_set_i32(h, "Volume", PREFS.volume);
        nvs_commit(h);
        nvs_close(h);
    }
    lib_key(g, key, sizeof(key));
    if (nvs_open("Shelf", NVS_READWRITE, &h) == ESP_OK) {
        nvs_set_str(h, "pend", key);
        nvs_set_i64(h, "pendt", now_s());
        nvs_commit(h);
        nvs_close(h);
    }
    prefs_save();

    esp_err_t err = part ? esp_ota_set_boot_partition(part) : ESP_ERR_NOT_FOUND;
    if (err != ESP_OK) {
        // ESP-IDF refused (or can't see the table): write the record the bootloader reads directly.
        ESP_LOGW(TAG, "esp_ota_set_boot_partition: %s, writing the boot record directly", esp_err_to_name(err));
        esp_err_t err2 = write_boot_record(otadata, count_ota_slots(&table), slot);
        if (err2 != ESP_OK) {
            describe_flash(&table, about, sizeof(about));
            snprintf(err_text, sizeof(err_text), "Couldn’t switch to the emulator (%s).\n%s", esp_err_to_name(err2), about);
            ESP_LOGE(TAG, "%s", err_text);
            clear_pending();
            return err_text;
        }
    }
    ESP_LOGI(TAG, "launching %s from slot %d", path, slot);
    esp_restart();
    return NULL;
}
