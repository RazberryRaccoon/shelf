// Shelf: a launcher for the Odroid GO.
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_heap_caps.h"
#include "esp_log.h"
#include "hal.h"
#include "gfx.h"
#include "audio.h"
#include "library.h"
#include "system.h"
#include "backdrop.h"
#include "ui.h"

static const char *TAG = "shelf";

void app_main(void)
{
    board_init();
    gfx_init(board_frame());
    gfx_fill(0, 0, SCREEN_W, SCREEN_H, 0);
    board_present();

    prefs_load();
    sound_init();
    sound_set_volume(PREFS.volume, PREFS.sound);

    if (!board_sd_mount()) {
        ui_message("Can’t read the SD card.\nCheck that it’s inserted and formatted as FAT32, then restart.", false);
    } else {
        system_log_flash();
        lib_scan();
        lib_load_meta();
        backdrops_build_async();
        ui_init();
    }
    ESP_LOGI(TAG, "free internal %u, PSRAM %u", (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL), (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));

    double last = board_seconds();
    int bl = 0;
    while (1) {
        double now = board_seconds();
        float dt = now - last;
        last = now;
        gfx_set_screen(board_frame());
        ui_frame(dt, board_input_read());
        board_present();
        if (bl < 100) { bl += 10; board_backlight(bl); }   // fade the screen in
        vTaskDelay(1);
    }
}
