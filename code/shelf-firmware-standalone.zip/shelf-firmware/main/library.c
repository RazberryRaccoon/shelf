#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>
#include "esp_log.h"
#include "cJSON.h"
#include "library.h"
#include "hal.h"

static const char *TAG = "library";
#define META_PATH "/sd/shelf/library.json"

const char *SYS_DIR[SYS_COUNT] = {"nes", "gb", "gbc"};
const char *SYS_NAME[SYS_COUNT] = {"NES", "Game Boy", "Game Boy Color"};
const char *SYS_LONG[SYS_COUNT] = {"NES cartridge", "Game Boy cartridge", "Game Boy Color cartridge"};
const char *SORT_LABEL[SORT_COUNT] = {"Sorted A to Z", "Recently played first", "Most played first", "Favorites first"};
shelf_t SHELVES[SYS_COUNT];

uint32_t shelf_hash(const char *s)
{
    uint32_t h = 2166136261u;
    while (*s) { h ^= (uint8_t)*s++; h *= 16777619u; }
    return h;
}

static const char *ext_of(const char *f)
{
    const char *d = strrchr(f, '.');
    return d ? d + 1 : "";
}

static bool wanted(sys_t s, const char *f)
{
    const char *e = ext_of(f);
    if (!strcasecmp(e, "zip")) return true;
    if (s == SYS_NES) return !strcasecmp(e, "nes");
    if (s == SYS_GB) return !strcasecmp(e, "gb");
    return !strcasecmp(e, "gbc");
}

// "Super Game (USA) [!].nes" -> "Super Game"
static void make_title(const char *file, char *out, int len)
{
    char t[128];
    str_copy(t, sizeof(t), file);
    char *dot = strrchr(t, '.'); if (dot) *dot = 0;
    for (char *p = t; *p; p++) if (*p == '_') *p = ' ';
    char *cut = NULL;
    for (char *p = t + 1; *p; p++) if ((*p == '(' || *p == '[') && p[-1] == ' ') { cut = p - 1; break; }
    if (cut && cut > t) *cut = 0;
    int n = strlen(t);
    while (n > 0 && t[n - 1] == ' ') t[--n] = 0;
    str_copy(out, len, t[0] ? t : file);
}

void lib_key(const game_t *g, char *out, int len) { snprintf(out, len, "%s/%s", SYS_DIR[g->sys], g->file); }
void lib_rom_path(const game_t *g, char *out, int len) { snprintf(out, len, "/sd/roms/%s/%s", SYS_DIR[g->sys], g->file); }

// The emulators keep saves in /sd/odroid/data/<rom extension>/<rom file name>.sav
void lib_save_path(const game_t *g, char *out, int len)
{
    char ext[16];
    str_copy(ext, sizeof(ext), ext_of(g->file));
    for (char *p = ext; *p; p++) *p = tolower((unsigned char)*p);
    snprintf(out, len, "/sd/odroid/data/%s/%s.sav", ext, g->file);
}

bool lib_check_save(game_t *g)
{
    char p[300];
    struct stat st;
    lib_save_path(g, p, sizeof(p));
    board_bus_lock();
    g->has_save = stat(p, &st) == 0 && st.st_size > 0;
    if (!g->has_save) {   // some builds drop the ROM's extension from the save name
        char base[128];
        str_copy(base, sizeof(base), g->file);
        char *dot = strrchr(base, '.'); if (dot) *dot = 0;
        char *slash = strrchr(p, '/');
        if (slash) { snprintf(slash + 1, sizeof(p) - (slash + 1 - p), "%s.sav", base); g->has_save = stat(p, &st) == 0 && st.st_size > 0; }
    }
    board_bus_unlock();
    return g->has_save;
}

void lib_scan(void)
{
    for (int s = 0; s < SYS_COUNT; s++) {
        shelf_t *sh = &SHELVES[s];
        free(sh->games);
        memset(sh, 0, sizeof(*sh));
        char dir[64];
        snprintf(dir, sizeof(dir), "/sd/roms/%s", SYS_DIR[s]);
        board_bus_lock();
        DIR *d = opendir(dir);
        if (!d) { board_bus_unlock(); ESP_LOGW(TAG, "no folder %s", dir); continue; }
        int cap = 32;
        sh->games = calloc(cap, sizeof(game_t));
        struct dirent *e;
        while ((e = readdir(d))) {
            if (e->d_name[0] == '.' || !wanted(s, e->d_name)) continue;
            if (strlen(e->d_name) >= sizeof(((game_t *)0)->file)) continue;
            if (sh->n == cap) { cap *= 2; sh->games = realloc(sh->games, cap * sizeof(game_t)); }
            game_t *g = &sh->games[sh->n++];
            memset(g, 0, sizeof(*g));
            str_copy(g->file, sizeof(g->file), e->d_name);
            make_title(g->file, g->title, sizeof(g->title));
            g->sys = s;
        }
        closedir(d);
        board_bus_unlock();
        for (int i = 0; i < sh->n; i++) lib_check_save(&sh->games[i]);
        ESP_LOGI(TAG, "%s: %d games", SYS_NAME[s], sh->n);
    }
}

void lib_load_meta(void)
{
    board_bus_lock();
    FILE *f = fopen(META_PATH, "rb");
    if (!f) { board_bus_unlock(); return; }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc(n + 1);
    if (!buf) { fclose(f); board_bus_unlock(); return; }
    size_t got = fread(buf, 1, n, f);
    buf[got] = 0;
    fclose(f);
    board_bus_unlock();
    cJSON *root = cJSON_Parse(buf);
    free(buf);
    if (!root) return;
    char key[160];
    for (int s = 0; s < SYS_COUNT; s++)
        for (int i = 0; i < SHELVES[s].n; i++) {
            game_t *g = &SHELVES[s].games[i];
            lib_key(g, key, sizeof(key));
            cJSON *o = cJSON_GetObjectItem(root, key);
            if (!o) continue;
            cJSON *t = cJSON_GetObjectItem(o, "t"), *q = cJSON_GetObjectItem(o, "q"), *fv = cJSON_GetObjectItem(o, "f");
            if (cJSON_IsNumber(t)) g->play_sec = (uint32_t)t->valuedouble;
            if (cJSON_IsNumber(q)) g->seq = (uint32_t)q->valuedouble;
            if (cJSON_IsNumber(fv)) g->fav = fv->valuedouble != 0;
        }
    cJSON_Delete(root);
}

void lib_save_meta(void)
{
    cJSON *root = cJSON_CreateObject();
    char key[160];
    for (int s = 0; s < SYS_COUNT; s++)
        for (int i = 0; i < SHELVES[s].n; i++) {
            game_t *g = &SHELVES[s].games[i];
            if (!g->play_sec && !g->seq && !g->fav) continue;
            cJSON *o = cJSON_CreateObject();
            cJSON_AddNumberToObject(o, "t", g->play_sec);
            cJSON_AddNumberToObject(o, "q", g->seq);
            cJSON_AddNumberToObject(o, "f", g->fav ? 1 : 0);
            lib_key(g, key, sizeof(key));
            cJSON_AddItemToObject(root, key, o);
        }
    char *txt = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!txt) return;
    board_bus_lock();
    mkdir("/sd/shelf", 0777);
    FILE *f = fopen(META_PATH ".tmp", "wb");
    if (f) {
        fputs(txt, f);
        fclose(f);
        remove(META_PATH);
        rename(META_PATH ".tmp", META_PATH);
    }
    board_bus_unlock();
    free(txt);
}

static int sort_mode;
static int cmp_title(const game_t *a, const game_t *b) { return strcasecmp(a->title, b->title); }
static int cmp(const void *pa, const void *pb)
{
    const game_t *a = pa, *b = pb;
    int r = 0;
    if (sort_mode == SORT_RECENT) r = (b->seq > a->seq) - (b->seq < a->seq);
    else if (sort_mode == SORT_MOST) r = (b->play_sec > a->play_sec) - (b->play_sec < a->play_sec);
    else if (sort_mode == SORT_FAV) r = (int)b->fav - (int)a->fav;
    return r ? r : cmp_title(a, b);
}

void lib_sort(shelf_t *sh, int mode)
{
    if (!sh->n) { sh->sort = mode; return; }
    char keep[128];
    str_copy(keep, sizeof(keep), sh->games[sh->sel].file);
    sort_mode = mode;
    sh->sort = mode;
    qsort(sh->games, sh->n, sizeof(game_t), cmp);
    for (int i = 0; i < sh->n; i++) if (!strcmp(sh->games[i].file, keep)) { sh->sel = i; break; }
}

game_t *lib_find(const char *key, int *sys_out, int *index_out)
{
    char k[160];
    for (int s = 0; s < SYS_COUNT; s++)
        for (int i = 0; i < SHELVES[s].n; i++) {
            lib_key(&SHELVES[s].games[i], k, sizeof(k));
            if (!strcmp(k, key)) { if (sys_out) *sys_out = s; if (index_out) *index_out = i; return &SHELVES[s].games[i]; }
        }
    return NULL;
}

uint32_t lib_max_seq(void)
{
    uint32_t m = 0;
    for (int s = 0; s < SYS_COUNT; s++) for (int i = 0; i < SHELVES[s].n; i++) if (SHELVES[s].games[i].seq > m) m = SHELVES[s].games[i].seq;
    return m;
}
