// Settings, and handing a game over to the emulator.
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "library.h"

typedef struct {
    uint8_t sound, motion, gb_green, attract, volume, shelf;
    uint8_t sort[SYS_COUNT];
    char sel[SYS_COUNT][128];      // selected file per shelf
} prefs_t;
extern prefs_t PREFS;

void prefs_load(void);
void prefs_save(void);

// Set when a game was launched; read back after the emulator returns.
void system_log_flash(void);   // writes what's in flash to the serial log

bool pending_take(char *key, int len, uint32_t *played_sec);

// Writes the handoff for the emulator and reboots into it. Only returns if that
// failed, with a description of what went wrong to show on screen.
const char *launch_game(game_t *g, bool resume);
