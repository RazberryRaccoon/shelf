// Odroid GO hardware: screen, buttons, battery, SD card.
#pragma once
#include <stdint.h>
#include <stdbool.h>

#define SCREEN_W 320
#define SCREEN_H 240

enum {
    BTN_UP = 1 << 0, BTN_DOWN = 1 << 1, BTN_LEFT = 1 << 2, BTN_RIGHT = 1 << 3,
    BTN_A = 1 << 4, BTN_B = 1 << 5, BTN_SELECT = 1 << 6, BTN_START = 1 << 7,
    BTN_MENU = 1 << 8, BTN_VOLUME = 1 << 9,
};

void board_init(void);
int board_nvs_status(void);                     // 0 if settings storage works, else the ESP-IDF error
bool board_sd_mount(void);

// Two frame buffers: draw into board_frame(), then board_present() hands it to the
// screen. The transfer runs on the other core while the next frame is drawn.
uint16_t *board_frame(void);
void board_present(void);

// The SD card shares the screen's SPI bus, so wrap every SD card access in these.
void board_bus_lock(void);
void board_bus_unlock(void);

void board_backlight(int percent);
uint32_t board_input_read(void);
int board_battery_percent(void);                // -1 while unknown
double board_seconds(void);                     // seconds since boot
