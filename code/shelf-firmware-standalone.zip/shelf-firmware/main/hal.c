// Odroid GO hardware layer for ESP-IDF v4.4.
#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "driver/ledc.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"
#include "esp_heap_caps.h"
#include "esp_timer.h"
#include "esp_vfs_fat.h"
#include "driver/sdspi_host.h"
#include "sdmmc_cmd.h"
#include "nvs_flash.h"
#include "esp_log.h"
#include "hal.h"

static const char *TAG = "board";

#define PIN_MISO    19
#define PIN_MOSI    23
#define PIN_CLK     18
#define PIN_LCD_CS   5
#define PIN_LCD_DC  21
#define PIN_LCD_BL  14
#define PIN_SD_CS   22
#define SPI_HOST_ID VSPI_HOST

// Screen orientation and color order. 0xA0 is right side up on the Odroid GO.
// If the picture is mirrored or red and blue are swapped, see the README.
#ifndef LCD_MADCTL
#define LCD_MADCTL 0xA0
#endif

#define PIN_BTN_SELECT 27
#define PIN_BTN_START  39
#define PIN_BTN_A      32
#define PIN_BTN_B      33
#define PIN_BTN_MENU   13
#define PIN_BTN_VOLUME  0
#define ADC_JOY_X   ADC1_CHANNEL_6   // GPIO34
#define ADC_JOY_Y   ADC1_CHANNEL_7   // GPIO35
#define ADC_BATTERY ADC1_CHANNEL_0   // GPIO36

#define LINES 24                     // lines per DMA chunk
static spi_device_handle_t lcd;
static uint16_t *dma_buf[2];
static spi_transaction_t trans[2];
static esp_adc_cal_characteristics_t adc_chars;

static uint16_t *frames[2];
static int drawing;                  // index of the frame being drawn
static volatile int showing = -1;    // index of the frame being sent
static SemaphoreHandle_t frame_ready, frame_sent, bus;
static int nvs_status;
int board_nvs_status(void) { return nvs_status; }

static void IRAM_ATTR lcd_pre_cb(spi_transaction_t *t)
{
    gpio_set_level(PIN_LCD_DC, (int)(intptr_t)t->user);
}

static void lcd_send(const uint8_t *data, int len, int dc)
{
    if (len <= 0) return;
    uint8_t buf[16];                 // copy so the data is in DMA-capable RAM
    memcpy(buf, data, len);
    spi_transaction_t t;
    memset(&t, 0, sizeof(t));
    t.length = len * 8;
    t.tx_buffer = buf;
    t.user = (void *)(intptr_t)dc;
    spi_device_polling_transmit(lcd, &t);
}
static void lcd_cmd(uint8_t c) { lcd_send(&c, 1, 0); }

typedef struct { uint8_t cmd; uint8_t data[15]; uint8_t len; } lcd_init_t;   // len 0x80 = then wait
static const lcd_init_t LCD_INIT[] = {
    {0x01, {0}, 0x80},
    {0xCF, {0x00, 0xC3, 0x30}, 3},
    {0xED, {0x64, 0x03, 0x12, 0x81}, 4},
    {0xE8, {0x85, 0x00, 0x78}, 3},
    {0xCB, {0x39, 0x2C, 0x00, 0x34, 0x02}, 5},
    {0xF7, {0x20}, 1},
    {0xEA, {0x00, 0x00}, 2},
    {0xC0, {0x1B}, 1},
    {0xC1, {0x12}, 1},
    {0xC5, {0x32, 0x3C}, 2},
    {0xC7, {0x91}, 1},
    {0x36, {LCD_MADCTL}, 1},
    {0x3A, {0x55}, 1},
    {0xB1, {0x00, 0x10}, 2},
    {0xB6, {0x0A, 0xA2}, 2},
    {0xF2, {0x00}, 1},
    {0x26, {0x01}, 1},
    {0xE0, {0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00}, 15},
    {0xE1, {0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F}, 15},
    {0x11, {0}, 0x80},
    {0x29, {0}, 0x80},
};

static void lcd_init(void)
{
    gpio_set_direction(PIN_LCD_DC, GPIO_MODE_OUTPUT);
    spi_bus_config_t buscfg = {
        .mosi_io_num = PIN_MOSI, .miso_io_num = PIN_MISO, .sclk_io_num = PIN_CLK,
        .quadwp_io_num = -1, .quadhd_io_num = -1,
        .max_transfer_sz = SCREEN_W * LINES * 2 + 16,
    };
    ESP_ERROR_CHECK(spi_bus_initialize(SPI_HOST_ID, &buscfg, SPI_DMA_CH_AUTO));
    spi_device_interface_config_t dev = {
        .clock_speed_hz = 40 * 1000 * 1000,
        .mode = 0,
        .spics_io_num = PIN_LCD_CS,
        .queue_size = 4,
        .pre_cb = lcd_pre_cb,
        .flags = SPI_DEVICE_NO_DUMMY,
    };
    ESP_ERROR_CHECK(spi_bus_add_device(SPI_HOST_ID, &dev, &lcd));
    for (size_t i = 0; i < sizeof(LCD_INIT) / sizeof(LCD_INIT[0]); i++) {
        lcd_cmd(LCD_INIT[i].cmd);
        lcd_send(LCD_INIT[i].data, LCD_INIT[i].len & 0x7F, 1);
        if (LCD_INIT[i].len & 0x80) vTaskDelay(pdMS_TO_TICKS(120));
    }
    for (int i = 0; i < 2; i++) {
        dma_buf[i] = heap_caps_malloc(SCREEN_W * LINES * 2, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
        assert(dma_buf[i]);
    }
}

static void push(const uint16_t *fb)
{
    const uint8_t caset[4] = {0, 0, (SCREEN_W - 1) >> 8, (SCREEN_W - 1) & 0xFF};
    const uint8_t paset[4] = {0, 0, (SCREEN_H - 1) >> 8, (SCREEN_H - 1) & 0xFF};
    lcd_cmd(0x2A); lcd_send(caset, 4, 1);
    lcd_cmd(0x2B); lcd_send(paset, 4, 1);
    lcd_cmd(0x2C);
    int pending = 0;
    spi_transaction_t *done;
    for (int y = 0, chunk = 0; y < SCREEN_H; y += LINES, chunk++) {
        int b = chunk & 1;
        if (pending == 2) { spi_device_get_trans_result(lcd, &done, portMAX_DELAY); pending--; }
        const uint32_t *src = (const uint32_t *)(fb + y * SCREEN_W);
        uint32_t *dst = (uint32_t *)dma_buf[b];
        for (int i = 0; i < SCREEN_W * LINES / 2; i++) {   // two pixels at a time, bytes swapped for the panel
            uint32_t v = src[i];
            dst[i] = ((v & 0x00FF00FF) << 8) | ((v >> 8) & 0x00FF00FF);
        }
        memset(&trans[b], 0, sizeof(trans[b]));
        trans[b].length = SCREEN_W * LINES * 16;
        trans[b].tx_buffer = dma_buf[b];
        trans[b].user = (void *)1;
        spi_device_queue_trans(lcd, &trans[b], portMAX_DELAY);
        pending++;
    }
    while (pending--) spi_device_get_trans_result(lcd, &done, portMAX_DELAY);
}

static void display_task(void *arg)
{
    while (1) {
        xSemaphoreTake(frame_ready, portMAX_DELAY);
        xSemaphoreTake(bus, portMAX_DELAY);
        push(frames[showing]);
        xSemaphoreGive(bus);
        xSemaphoreGive(frame_sent);
    }
}

uint16_t *board_frame(void) { return frames[drawing]; }

void board_present(void)
{
    xSemaphoreTake(frame_sent, portMAX_DELAY);   // wait until the previous frame is on screen
    showing = drawing;
    drawing ^= 1;
    xSemaphoreGive(frame_ready);
}

void board_bus_lock(void) { if (bus) xSemaphoreTake(bus, portMAX_DELAY); }
void board_bus_unlock(void) { if (bus) xSemaphoreGive(bus); }

void board_backlight(int percent)
{
    if (percent < 0) percent = 0;
    if (percent > 100) percent = 100;
    ledc_set_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0, percent * 1023 / 100);
    ledc_update_duty(LEDC_HIGH_SPEED_MODE, LEDC_CHANNEL_0);
}

static void backlight_init(void)
{
    ledc_timer_config_t tc = {
        .speed_mode = LEDC_HIGH_SPEED_MODE, .duty_resolution = LEDC_TIMER_10_BIT,
        .timer_num = LEDC_TIMER_0, .freq_hz = 5000, .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&tc);
    ledc_channel_config_t cc = {
        .gpio_num = PIN_LCD_BL, .speed_mode = LEDC_HIGH_SPEED_MODE, .channel = LEDC_CHANNEL_0,
        .intr_type = LEDC_INTR_DISABLE, .timer_sel = LEDC_TIMER_0, .duty = 0, .hpoint = 0,
    };
    ledc_channel_config(&cc);
}

static void input_init(void)
{
    const int pins[] = {PIN_BTN_SELECT, PIN_BTN_START, PIN_BTN_A, PIN_BTN_B, PIN_BTN_MENU, PIN_BTN_VOLUME};
    for (int i = 0; i < 6; i++) {
        gpio_set_direction(pins[i], GPIO_MODE_INPUT);
        if (pins[i] != PIN_BTN_START) gpio_set_pull_mode(pins[i], GPIO_PULLUP_ONLY);   // GPIO39 has no pull-up
    }
    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(ADC_JOY_X, ADC_ATTEN_DB_12);
    adc1_config_channel_atten(ADC_JOY_Y, ADC_ATTEN_DB_12);
    adc1_config_channel_atten(ADC_BATTERY, ADC_ATTEN_DB_12);
    esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_12, ADC_WIDTH_BIT_12, 1100, &adc_chars);
}

uint32_t board_input_read(void)
{
    uint32_t s = 0;
    int x = adc1_get_raw(ADC_JOY_X), y = adc1_get_raw(ADC_JOY_Y);
    if (y > 2048 + 1024) s |= BTN_UP; else if (y > 1024) s |= BTN_DOWN;
    if (x > 2048 + 1024) s |= BTN_LEFT; else if (x > 1024) s |= BTN_RIGHT;
    if (!gpio_get_level(PIN_BTN_SELECT)) s |= BTN_SELECT;
    if (!gpio_get_level(PIN_BTN_START)) s |= BTN_START;
    if (!gpio_get_level(PIN_BTN_A)) s |= BTN_A;
    if (!gpio_get_level(PIN_BTN_B)) s |= BTN_B;
    if (!gpio_get_level(PIN_BTN_MENU)) s |= BTN_MENU;
    if (!gpio_get_level(PIN_BTN_VOLUME)) s |= BTN_VOLUME;
    return s;
}

int board_battery_percent(void)
{
    static float smooth = -1;
    static double last = -10;
    double now = board_seconds();
    if (now - last >= 2.0 || smooth < 0) {
        last = now;
        uint32_t raw = 0;
        for (int i = 0; i < 8; i++) raw += adc1_get_raw(ADC_BATTERY);
        float mv = esp_adc_cal_raw_to_voltage(raw / 8, &adc_chars) * 2.0f;   // 1:2 divider on the board
        float pct = (mv - 3500.0f) * 100.0f / (4200.0f - 3500.0f);
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;
        smooth = smooth < 0 ? pct : smooth * 0.8f + pct * 0.2f;
    }
    return (int)(smooth + 0.5f);
}

double board_seconds(void) { return esp_timer_get_time() / 1000000.0; }

bool board_sd_mount(void)
{
    sdmmc_host_t host = SDSPI_HOST_DEFAULT();
    host.slot = SPI_HOST_ID;
    host.max_freq_khz = SDMMC_FREQ_DEFAULT;
    sdspi_device_config_t slot = SDSPI_DEVICE_CONFIG_DEFAULT();
    slot.gpio_cs = PIN_SD_CS;
    slot.host_id = host.slot;
    esp_vfs_fat_sdmmc_mount_config_t mc = {
        .format_if_mount_failed = false, .max_files = 4, .allocation_unit_size = 16 * 1024,
    };
    sdmmc_card_t *card;
    board_bus_lock();
    esp_err_t err = esp_vfs_fat_sdspi_mount("/sd", &host, &slot, &mc, &card);
    board_bus_unlock();
    if (err != ESP_OK) ESP_LOGE(TAG, "SD card mount failed: %s", esp_err_to_name(err));
    return err == ESP_OK;
}

void board_init(void)
{
    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        nvs_flash_erase();
        err = nvs_flash_init();
    }
    nvs_status = err;
    if (err != ESP_OK) ESP_LOGE(TAG, "settings storage: %s", esp_err_to_name(err));
    backlight_init();
    lcd_init();
    input_init();
    for (int i = 0; i < 2; i++) {
        frames[i] = heap_caps_malloc(SCREEN_W * SCREEN_H * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        if (!frames[i]) frames[i] = heap_caps_malloc(SCREEN_W * SCREEN_H * 2, MALLOC_CAP_8BIT);
        assert(frames[i]);
        memset(frames[i], 0, SCREEN_W * SCREEN_H * 2);
    }
    frame_ready = xSemaphoreCreateBinary();
    frame_sent = xSemaphoreCreateBinary();
    bus = xSemaphoreCreateMutex();
    xSemaphoreGive(frame_sent);
    xTaskCreatePinnedToCore(display_task, "display", 3072, NULL, 4, NULL, 1);
}
